﻿namespace CheckClikClient.Models
{
    public class CategorySubCategory
    {
        public List<Category> lstCategories { get; set; }
        public List<SubCategory> lstSubCategories { get; set; }

    }
}
