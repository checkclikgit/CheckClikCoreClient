﻿namespace CheckClikClient.Models
{
    public class FileAttribs
    {
        public string FileName { get; set; }
        public string Base64FileData { get; set; }
        public String FileUploadLocation { get; set; }
        public string FileURLLocation { get; set; }
    }
}
