﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Customer.Models
{
    public class ItemVariantsDTO
    {
        public string OptionEn { get; set; }
        public string OptionAr { get; set; }
        public string OptionValueEn { get; set; }
        public string OptionValueAr { get; set; }
    }
}