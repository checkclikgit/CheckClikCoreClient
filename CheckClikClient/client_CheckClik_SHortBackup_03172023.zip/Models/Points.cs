﻿namespace CheckClikClient.Models
{
    public class Points
    {
        public int PaymentType { get; set; }
        
    }
}
